import express from 'express';
import { storage } from './storage.js';
import { generateChatResponse } from './ai.js';
import { messageSchema } from '../shared/schema.js';

const app = express();
app.use(express.json());

// CORS for development
app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Headers', 'Content-Type');
  next();
});

// Create new conversation
app.post('/api/conversations', async (req, res) => {
  const conversationId = Date.now().toString();
  const conversation = {
    id: conversationId,
    messages: [],
    createdAt: Date.now(),
  };
  
  await storage.saveConversation(conversation);
  res.json({ conversationId });
});

// Get conversation
app.get('/api/conversations/:id', async (req, res) => {
  const conversation = await storage.getConversation(req.params.id);
  if (!conversation) {
    return res.status(404).json({ error: 'Conversation not found' });
  }
  res.json(conversation);
});

// Send message and get streaming response
app.post('/api/messages', async (req, res) => {
  try {
    const { conversationId, content } = req.body;

    // Get conversation
    const conversation = await storage.getConversation(conversationId);
    if (!conversation) {
      return res.status(404).json({ error: 'Conversation not found' });
    }

    // Add user message
    const userMessage = {
      id: Date.now().toString(),
      role: 'user' as const,
      content,
      timestamp: Date.now(),
    };
    await storage.addMessage(conversationId, userMessage);

    // Set up SSE
    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Connection', 'keep-alive');

    let assistantResponse = '';

    // Generate response with streaming
    const fullResponse = await generateChatResponse(
      [...conversation.messages, userMessage],
      (chunk) => {
        assistantResponse += chunk;
        res.write(`data: ${JSON.stringify({ type: 'chunk', content: chunk })}\n\n`);
      }
    );

    // Save assistant message
    const assistantMessage = {
      id: (Date.now() + 1).toString(),
      role: 'assistant' as const,
      content: fullResponse,
      timestamp: Date.now(),
    };
    await storage.addMessage(conversationId, assistantMessage);

    res.write(`data: ${JSON.stringify({ type: 'done', message: assistantMessage })}\n\n`);
    res.end();
  } catch (error) {
    console.error('Error:', error);
    res.write(`data: ${JSON.stringify({ type: 'error', error: 'Failed to generate response' })}\n\n`);
    res.end();
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`🚀 CNG Chatbot server running on http://localhost:${PORT}`);
});

export default app;
