import Anthropic from '@anthropic-ai/sdk';
import { Message } from '../shared/schema.js';

const anthropic = new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY || '',
});

const CNG_SYSTEM_PROMPT = `You are a helpful assistant for Calgary Newcomers Guide (CNG), an organization that helps newcomers to Calgary, Canada settle and integrate into the community.

Your role is to:
1. Answer questions about CNG programs and services
2. Provide information about settlement resources in Calgary
3. Guide users to appropriate programs based on their needs
4. Be warm, welcoming, and culturally sensitive

CNG offers programs in areas such as:
- Employment services and job search support
- Language learning (ESL classes)
- Settlement services and orientation
- Community connections and networking
- Housing assistance and information
- Newcomer youth programs
- Family support services

Always be helpful, respectful, and provide accurate information. If you're unsure about specific program details, acknowledge this and suggest the user contact CNG directly.`;

export async function generateChatResponse(
  messages: Message[],
  onChunk: (chunk: string) => void
): Promise<string> {
  const formattedMessages = messages.map(msg => ({
    role: msg.role,
    content: msg.content,
  }));

  let fullResponse = '';

  const stream = await anthropic.messages.create({
    model: 'claude-sonnet-4-5-20250929',
    max_tokens: 1024,
    system: CNG_SYSTEM_PROMPT,
    messages: formattedMessages,
    stream: true,
  });

  for await (const event of stream) {
    if (
      event.type === 'content_block_delta' &&
      event.delta.type === 'text_delta'
    ) {
      const chunk = event.delta.text;
      fullResponse += chunk;
      onChunk(chunk);
    }
  }

  return fullResponse;
}
