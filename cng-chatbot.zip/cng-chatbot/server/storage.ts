import { Conversation, Message } from '../shared/schema.js';

export interface IStorage {
  getConversation(id: string): Promise<Conversation | null>;
  saveConversation(conversation: Conversation): Promise<void>;
  addMessage(conversationId: string, message: Message): Promise<void>;
}

export class MemStorage implements IStorage {
  private conversations: Map<string, Conversation> = new Map();

  async getConversation(id: string): Promise<Conversation | null> {
    return this.conversations.get(id) || null;
  }

  async saveConversation(conversation: Conversation): Promise<void> {
    this.conversations.set(conversation.id, conversation);
  }

  async addMessage(conversationId: string, message: Message): Promise<void> {
    const conversation = await this.getConversation(conversationId);
    if (conversation) {
      conversation.messages.push(message);
      await this.saveConversation(conversation);
    }
  }
}

export const storage = new MemStorage();
